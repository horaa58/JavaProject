/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.smaetparkingmanagment;

/**
 *
 * @author hoory
 */
public class SmaetParkingManagment {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
