/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.smaetparkingmanagment;

/**
 *
 * @author hoory
 */

public class ParkingEntry {

    private String entryID;
    private String vehicleNumber;
    private String ownerName;
    private String parkingSlot;
    private String entryDate;
    private String entryTime;
    private String exitDate;
    private String exitTime;
    private double parkingHours;
    private double hourlyRate;
    private double discount;
    private double parkingFee;
    private double finalAmount;
    private String paymentStatus;
    private String status;


    public ParkingEntry(String entryID, String vehicleNumber, String ownerName,
            String parkingSlot, String entryDate, String entryTime,
            String exitDate, String exitTime,
            double parkingHours, double hourlyRate,
            double discount, double parkingFee,
            double finalAmount, String paymentStatus,
            String status) {

        this.entryID = entryID;
        this.vehicleNumber = vehicleNumber;
        this.ownerName = ownerName;
        this.parkingSlot = parkingSlot;
        this.entryDate = entryDate;
        this.entryTime = entryTime;
        this.exitDate = exitDate;
        this.exitTime = exitTime;
        this.parkingHours = parkingHours;
        this.hourlyRate = hourlyRate;
        this.discount = discount;
        this.parkingFee = parkingFee;
        this.finalAmount = finalAmount;
        this.paymentStatus = paymentStatus;
        this.status = status;
    }


    public String getEntryID() {
        return entryID;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public String getParkingSlot() {
        return parkingSlot;
    }

    public String getEntryDate() {
        return entryDate;
    }

    public String getEntryTime() {
        return entryTime;
    }

    public String getExitDate() {
        return exitDate;
    }

    public String getExitTime() {
        return exitTime;
    }

    public double getParkingHours() {
        return parkingHours;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    public double getDiscount() {
        return discount;
    }

    public double getParkingFee() {
        return parkingFee;
    }

    public double getFinalAmount() {
        return finalAmount;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public String getStatus() {
        return status;
    }


    public void setExitDate(String exitDate) {
        this.exitDate = exitDate;
    }

    public void setExitTime(String exitTime) {
        this.exitTime = exitTime;
    }

    public void setParkingHours(double parkingHours) {
        this.parkingHours = parkingHours;
    }

    public void setParkingFee(double parkingFee) {
        this.parkingFee = parkingFee;
    }

    public void setFinalAmount(double finalAmount) {
        this.finalAmount = finalAmount;
    }
    

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
