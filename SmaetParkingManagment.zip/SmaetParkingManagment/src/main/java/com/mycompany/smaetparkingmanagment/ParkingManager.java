/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.smaetparkingmanagment;


import java.util.ArrayList;
/**
 *
 * @author hoory
 */
public class ParkingManager {

    private ArrayList<ParkingEntry> parkingList;

    public ParkingManager() {
        parkingList = new ArrayList<>();
    }

    // Add a parking entry
    public void addParkingEntry(ParkingEntry entry) {
        parkingList.add(entry);
    }

    // Return the list of parking entries
    public ArrayList<ParkingEntry> getParkingList() {
        return parkingList;
    }

    // Remove a parking entry
    public void removeParkingEntry(int index) {
        parkingList.remove(index);
    }

    // Update a parking entry
    public void updateParkingEntry(int index, ParkingEntry entry) {
        parkingList.set(index, entry);
    }
    

    // Search by Entry ID
    public ParkingEntry searchParkingEntry(String entryID) {

        for (ParkingEntry entry : parkingList) {
            if (entry.getEntryID().equalsIgnoreCase(entryID)) {
                return entry;
            }
        }

        return null;
    }
}

