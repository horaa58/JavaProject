/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.smaetparkingmanagment;

import java.io.*;
import java.util.ArrayList;

public class FileHandler {

    private final String FILE_NAME = "parkingData.txt";

    public void saveData(ArrayList<ParkingEntry> parkingList) {

        try {

            PrintWriter writer = new PrintWriter(new FileWriter(FILE_NAME));

            for (ParkingEntry p : parkingList) {

                writer.println(
                        p.getEntryID() + "," +
                        p.getVehicleNumber() + "," +
                        p.getOwnerName() + "," +
                        p.getParkingSlot() + "," +
                        p.getEntryDate() + "," +
                        p.getEntryTime() + "," +
                        p.getExitDate() + "," +
                        p.getExitTime() + "," +
                        p.getParkingHours() + "," +
                        p.getHourlyRate() + "," +
                        p.getDiscount() + "," +
                        p.getParkingFee() + "," +
                        p.getFinalAmount() + "," +
                        p.getPaymentStatus() + "," +
                        p.getStatus()
                );

            }

            writer.close();

        } catch (IOException e) {

            e.printStackTrace();

        }

    }

    public ArrayList<ParkingEntry> loadData() {

        ArrayList<ParkingEntry> parkingList = new ArrayList<>();

        File file = new File(FILE_NAME);

        if (!file.exists()) {

            return parkingList;

        }

        try {

            BufferedReader reader = new BufferedReader(new FileReader(file));

            String line;

            while ((line = reader.readLine()) != null) {

                String[] data = line.split(",");

                ParkingEntry entry = new ParkingEntry(

                        data[0],
                        data[1],
                        data[2],
                        data[3],
                        data[4],
                        data[5],
                        data[6],
                        data[7],
                        Double.parseDouble(data[8]),
                        Double.parseDouble(data[9]),
                        Double.parseDouble(data[10]),
                        Double.parseDouble(data[11]),
                        Double.parseDouble(data[12]),
                        data[13],
                        data[14]

                );

                parkingList.add(entry);

            }

            reader.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

        return parkingList;

    }
    
    

}
